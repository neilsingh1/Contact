class Usage < ApplicationRecord
    has_many :contacts
end
