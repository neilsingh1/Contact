class Contact < ApplicationRecord
    belongs_to :usage
end
