class ContactsController < ApplicationController

def index
    @all_contacts = Contact.order(:brand)
 end
    
  def show
    contact_id = params[:id]
    @contact = Contact.find(contact_id)
  end
    
  def create
    contact = Contact.new
    contact.brand = params[:contact][:brand]
    contact.model = params[:contact][:model]
    contact.usage = params[:contact][:usage]
    contact.power = params[:contact][:power]
    contact.notes = params[:contact][:notes]
    contact.save
    redirect_to "/contacts"
  end
  
  def edit
    @contact = Contact.find(params[:id])
  end
  
  def update
    contact = Contact.find(params[:id])
    contact.brand = params[:contact][:brand]
    contact.model = params[:contact][:model]
    contact.usage = params[:contact][:usage]
    contact.power = params[:contact][:power]
    contact.notes = params[:contact][:notes]
    contact.save
    redirect_to "/contacts"
  end
  
  def destroy
    contact = Contact.find(params[:id])
    contact.delete
    redirect_to "/contacts"
  end
  
end
  