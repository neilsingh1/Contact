class UsagesController < ApplicationController
    
  def index
    @usages = Usage.all
  end
  
  def show
    @usage = Usage.find(params[:id])
    @all_contacts = @usage.contacts.order(:brand)
  end
  
  def new
    @usage = Usage.new
  end
  
  def create
    @usage = Usage.new
    @usage.name = params[:usage][:name]
    @usage.save
    redirect_to "/usages"
  end
  
  def edit
    @usage = Usage.find(params[:id])
  end
  
  def update
    @usage = Usage.find(params[:id])
    @usage.name = params[:usage][:name]
    @usage.save
    redirect_to "/usages"
  end
  
  def destroy
    @usage = Usage.find(params[:id])
    @usage.delete
    redirect_to "/usages"
  end
  
end
