Rails.application.routes.draw do
  resources :usages
  resources :contacts
    
  root to: "contacts#index"
end