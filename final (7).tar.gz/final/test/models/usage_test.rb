require 'test_helper'

class UsageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
