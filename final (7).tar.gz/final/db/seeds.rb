# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

Usage.delete_all
Contact.delete_all

daily = Usage.new
daily.usage = "Daily"
daily.save

weekly = Usage.new
weekly.usage = "Weekly"
weekly.save

monthly = Usage.new
monthly.usage = "Monthly"
monthly.save


contact = Contact.new
contact.brand = "Acuvue"
contact.model = "Oasys"
contact.usage = "weekly"
contact.power = "-12.00 to +8.00"
contact.notes = "available in daily contact lenses"
contact.save

contact = Contact.new
contact.brand = "Air Optyx"
contact.model = "Aqua"
contact.usage = "weekly"
contact.power = "-12.00 to +8.00"
contact.notes = "not available in daily contact lenses"
contact.save

contact = Contact.new
contact.brand = "DAILIES"
contact.model = "AquaComfort"
contact.usage = "weekly"
contact.power = "-12.00 to +8.00"
contact.notes = "available in daily contact lenses"
contact.save

contact = Contact.new
contact.brand = "Biofinity"
contact.model = "toric"
contact.usage = "monthly"
contact.power = "-12.00 to +8.00"
contact.notes = "not available in daily contact lenses"
contact.save

contact = Contact.new
contact.brand = "Proclear"
contact.model = "1-Day"
contact.usage = "daily"
contact.power = "-12.00 to +8.00"
contact.notes = "not available in other usage contact lenses"
contact.save

contact = Contact.new
contact.brand = "FreshLook"
contact.model = "Colors"
contact.usage = "weekly"
contact.power = "-12.00 to +8.00"
contact.notes = "not available in daily contact lenses"
contact.save

contact = Contact.new
contact.brand = "SofLens"
contact.model = "Toric"
contact.usage = "weekly"
contact.power = "-12.00 to +8.00"
contact.notes = "available in daily contact lenses"
contact.save

contact = Contact.new
contact.brand = "Clariti"
contact.model = "1day"
contact.usage = "dauly"
contact.power = "-12.00 to +8.00"
contact.notes = "not available in other usage contact lenses"
contact.save

contact = Contact.new
contact.brand = "Biotrue"
contact.model = "ONEday"
contact.usage = "daily"
contact.power = "-12.00 to +8.00"
contact.notes = "not available in other usage contact lenses"
contact.save

contact = Contact.new
contact.brand = "AquaSoft"
contact.model = "Daily"
contact.usage = "daily"
contact.power = "-12.00 to +8.00"
contact.notes = "not available in other usage contact lenses"
contact.save


puts "Brands created!"