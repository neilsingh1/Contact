class CreateContacts < ActiveRecord::Migration[5.0]
  def change
    create_table :contacts do |t|
      t.text :brand
      t.text :model
      t.text :usage
      t.text :power
      t.text :notes

      t.timestamps
    end
  end
end
